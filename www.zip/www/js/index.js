
/*-- Global Variable Declarations --*/

/* Local Server */
//var webServiceURL = "http://172.16.11.67:800/IOTimeSheetsServices.svc/restful/";

/*sarmick system ip*/
//var webServiceURL = "http://172.16.11.242:800/IOTimeSheetsServices.svc/restful/";

/*shankar*/
//var webServiceURL = "http://123.255.250.197:2239/IOTimeSheetsServices.svc/restful/";

/* Staging Server */
var webServiceURL = "http://202.129.196.131:800/IOTimeSheetsServices.svc/restful/";

var db;
var parameter;
var i;
var j=0;
var jobName;
var taskName;
var units;
var lineNumber;
var str;
var now;
var day;
var month;
var currentDate;
var fullDate;
var submitFullDate;
var year;
var timeSheetStatus;
var hoursTypeListArray = [];
var jobListArray = [];
var taskListArray = [];
var taskListArrayAutoComplete = [];
var jobno;
var fromViewPg = 0;
var first;
var last;
var firstFullDate;
var lastFullDate;
var fortNightDays;
var timeSheetSavedFrom;
var hoursTypeTextFieldValue;
var jobListTextFieldValue;
var taskListTextFieldValue;
var payRollPeriodStartingDate;
var payRollPeriodEndingDate;
var payRollPeriods = [];
var yesterday;
var HoursPerWeek;
var timeSheetEmpName;
var empWorkedHours;
var fromPg;
var frm = 0;
var weeklyPeriod;
var weeklyPeriodSplit;
var pwdRegEx = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@!*#?&^_.:~`|])[A-Za-z\d$@!*#?&^_.:~`|]{8,}$/;
var hoursUnits = /^[0-9]*\.[0-9]{2}$/;
var popUpDeleteIcon;
var plantEntryNo;
var simpleList;
var submittedList;
var approvedList;
var rejectedList;
var generatingTimesheetListViewType;
var noOfPlantEntry;
var plantEntriView = 0;

/*-- Device Ready Function Call Everytime When App Lauches --*/

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    
//    if(localStorage.getItem("firstLogin") == null){
//    localStorage.setItem("firstLogin","0");
//    $.mobile.changePage("#timeSheetPreviewPg", {
//                        transition: "fade",
//                        changeHash: false
//                        });
//    }else{
//        changePage("#timeSheetLoginPg","slide",true);
//    }

    StatusBar.styleLightContent();
    StatusBar.overlaysWebView(false);
    StatusBar.backgroundColorByHexString("#555555");
    
}

/*-- Resume Function Calls Everytime When App Lauches from background --*/

document.addEventListener("resume", appWhenResumedFromBackground, false);

/*-- Function to change to login page when app restore from background location --*/

function appWhenResumedFromBackground(){

    changePage("#timeSheetLoginPg", "slide", true);
    //$("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
}

/*-- Function Calls When User Press Android BackButton --*/

/* 
 document.addEventListener("deviceready", androidBackButtonPress, false);

function androidBackButtonPress(e){
    
    if(device.platform == "android" || device.platform == "Android"){
        if(type=="submit"){
            e.preventDefault();
        }
        
    }
}
 */

/*-- Pagecontainershow --*/

/*-- Function Call Based On Page ID --*/

$(document).on("pagecontainershow", function(event, ui) {
               
               var activePage = $.mobile.pageContainer.pagecontainer("getActivePage");
               
               activePageName = activePage.attr('id');
               
               switch (activePage.attr('id')) {
//               case 'timeSheetLoginPg':
//               clearAllFieldsOfLoginPg();
//               break;
               case 'timeSheetChangePasswordPg':
               clearAllFieldsOfChangePwdPg();
               break;
               case 'timeSheetPg':
               timeSheetEmptyFromToDateField();
               break;
               case 'timeSheetButtonPg':
               getEmpDetails();
               break;
               }
               });

/*-- Pagecontainershow End --*/

/*-- Common Method To Shows Dialog Box --*/

function showAlert(alertmessage, title, callBack_func) {
    if (callBack_func) {
        navigator.notification.alert(alertmessage, callBack_func, title, "OK");
    } else {
        navigator.notification.alert(alertmessage, false, title, "OK");
    }
}

/*-- Dialog Box Method End --*/

/*-- Common Prompt Alert --*/

function promptAlert(alertmessage, callBack_func, title, buttonLabels1, buttonLabels2) {
    
    if (callBack_func) {
        navigator.notification.confirm(alertmessage, callBack_func, title, [buttonLabels1, buttonLabels2]);
    } else {
        navigator.notification.confirm(alertmessage, false, title, [buttonLabels1, buttonLabels2]);
    }
}

/*-- End Common Prompt Alert --*/


/*-- Common Prompt Alert --*/

function multiplePromptAlert(alertmessage, callBack_func, title, buttonLabels1, buttonLabels2, buttonLabels3) {
    
    if (callBack_func) {
        navigator.notification.confirm(alertmessage, callBack_func, title, [buttonLabels1, buttonLabels2, buttonLabels3]);
    } else {
        navigator.notification.confirm(alertmessage, false, title, [buttonLabels1, buttonLabels2, buttonLabels3]);
    }
}

/*-- End Common Prompt Alert --*/

/*-- ChangePage Function --*/

function changePage(pagename, pageTransition, isReverse) {
    
    $.mobile.changePage(pagename, {
                        transition: pageTransition,
                        changeHash: false,
                        reverse: isReverse
                        });
    
}

/*-- End of ChangePage Function --*/


/*-- Method To Check Internet Connection --*/

function checkConnection() {
    
    var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN] = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI] = 'WiFi connection';
    states[Connection.CELL_2G] = 'Cell 2G connection';
    states[Connection.CELL_3G] = 'Cell 3G connection';
    states[Connection.CELL_4G] = 'Cell 4G connection';
    states[Connection.NONE] = 'No network connection';
    if (states[networkState] == 'No network connection') {
        return false;
    } else {
        return true;
    }
}

/*-- End of Internet Connection Method --*/


/*-- Common Method To Show Loading Icon While Calling Webservice  --*/

function Apploadingicon() {
    
    $("body").append("<div class='modalWindow'/>");
    $("body").bind("touchmove", function(e) {
                   e.preventDefault()
                   });
    
    $.mobile.loading("show", {
                     text: "",
                     textVisible: false,
                     theme: "",
                     html: ""
                     });
    
}

/*-- End Of Loading Icon Method --*/


/*-- Method To Hide App Loading Icon --*/

function hideLoadingIcon() {
    
    $("body").unbind("touchmove");
    $(".modalWindow").remove();
    $.mobile.loading("hide");
    
}

/*-- End Of Method App Loading Icon --*/


/*-- Exception Handling Method --*/

function errorHandling(originalCode) {
    try {
        originalCode();
    } catch (err) {
        alert(err.message);
    }
}

/*-- End Of Exception Handling Block --*/


/*-- Common Method To Call WebService  --*/

function timeSheetWebService(requestType, methodName, param, callBack) {
    
    errorHandling(function() {
                  Apploadingicon();
                  if (checkConnection()) {
                  $.ajax({
                         type: "" + requestType + "",
                         url: webServiceURL + "" + methodName + "",
                         data: JSON.stringify(param),
                         dataType: "json",
                         contentType: "application/json; charset=utf-8",
                         success: function(msg) {
                         callBack(msg);
                         },
                         error: function(xhr) {
                         console.log(JSON.stringify(xhr));
                         showAlert("Webservice Error", "Timesheet");
                         hideLoadingIcon();
                         /* To uncheck platn entry checkbox */
                         //$("#timeSheetPlantEntry").prop("checked",false).checkboxradio("refresh");
                         }
                         });
                  } else {
                  showAlert("Please check internet connection.", "Timesheet");
                  hideLoadingIcon();
                  }
                  });
}

/*-- End Of Common WebService Method --*/


/*-- Logout Function --*/

function timeSheetLogout(){
    Apploadingicon();
    promptAlert("Are you sure you want to logout?", logout, "Timesheet", "Yes", "No");
}

function logout(btnIndex){
    if(btnIndex==1){
        hideLoadingIcon();
        changePage("#timeSheetLoginPg", "slide", true);
    }else{
        hideLoadingIcon();
        //console.log("stay in same page");
    }
    
}

/*-- End Of Logout Function --*/


/*-- Clear all fields of changepassword screen */

function clearAllFieldsOfChangePwdPg(){
    $("#timeSheetOldPwd").val("");
    $("#timeSheetNewPwd").val("");
    $("#timeSheetConfirmNewPwd").val("");
}

/*-- End Of Function --*/

/*-- Change Password Function */

function timeSheetChangePassword(){
    
    if(($("#timeSheetOldPwd").val()== "") && ($("#timeSheetNewPwd").val()== "") && ($("#timeSheetConfirmNewPwd").val()== "")){
        showAlert("Please enter all fields.","Timesheet", function(){
                  $("#timeSheetOldPwd").focus();
                  });
    }else if($("#timeSheetOldPwd").val()== ""){
        showAlert("Please enter old password.","Timesheet", function(){
                  $("#timeSheetOldPwd").focus();
                  });
    }else if($("#timeSheetNewPwd").val()== ""){
        showAlert("Please enter new password.","Timesheet", function(){
                  $("#timeSheetNewPwd").focus();
                  });
    }else if($("#timeSheetConfirmNewPwd").val()== ""){
        showAlert("Please enter confirm password.","Timesheet", function(){
                  $("#timeSheetConfirmNewPwd").focus();
                  });
    }else if(!(pwdRegEx.test($("#timeSheetConfirmNewPwd").val()))){
        showAlert("Password should have atlease one alphabet, one special symbols/characters and minimum of 8 characters.","Timesheet");
    }else if($("#timeSheetOldPwd").val() != localStorage.getItem("timeSheetPassword")){
         showAlert("Old Password is not correct.","Timesheet");
    }else {
        
        if($("#timeSheetNewPwd").val() != $("#timeSheetConfirmNewPwd").val()){
            showAlert("New password & confirm password doesn't match.","Timesheet");
        }else{
        
        parameter = {"employee":{
            "EmployeeNo": localStorage.getItem("timeSheetEmployeeNumber"),
            "Password": $("#timeSheetOldPwd").val(),
            "CurrentPassword":$("#timeSheetNewPwd").val()
        }}
            
        timeSheetWebService("POST", "ChangeCurrentPassword", parameter, function(response) {
                               //console.log(JSON.stringify(parameter));
                               // console.log("ChangeCurrentPassword"+JSON.stringify(response));
                                if (response.ChangeCurrentPasswordResult) {
                                hideLoadingIcon();
                                showAlert("Please use your new password to login.", "Password successfully changed", function(){
                                changePage("#timeSheetLoginPg","slide",true);
                                      });
                                } else {
                                hideLoadingIcon();
                                showAlert("Unable to change password please tryagain later.", "Timesheet");
                                }
                            
                                });
        }
            
        }
    }


/*-- End Of Change Password Function --*/

/*--Function To Clear All Fields Of Login Page--*/

function clearAllFieldsOfLoginPg()
{
    /*-- Code to change the theme color while login and logout--*/
    
    if(($("#timeSheetsTheme").val())=="template1"){
        $(".ui-btn, .ui-header").css({"background-color":"#74203f","color":"#ffffff","text-shadow":"none","border-color":"#74203f"});
        $(".timeSheetsTheme").css({"color":"#74203f"});
    }else if(($("#timeSheetsTheme").val())=="default"){
        $(".ui-btn, .ui-header").css({"background-color":"#375BAA","color":"#ffffff","text-shadow":"none","border-color":"#375BAA"});
        $(".timeSheetsTheme").css({"color":"#375BAA"});
    }
    
    $("#timeSheetLoginPgUserName").val("");
    $("#timeSheetLoginPgPassword").val("");
}

/*-- End Of Function --*/

/* Function to go back from change password page to othe page*/

function goBackFromChangePwdPg(){
    
    changePage("#"+changePwdPg, "slide", "true");
    
}
/*-- End Of Function --*/

/*-- Timesheet Login Function --*/

function timesheetLogin(){
    
//    fromPg = $.mobile.activePage.attr("id");
    if($("#timeSheetLoginPgUserName").val()==""||$("#timeSheetLoginPgUserName").val()==" "||$("#timeSheetLoginPgUserName").val()==undefined || $("#timeSheetLoginPgUserName").val()== null){
        showAlert("Please enter your Username.","Timesheet", function(){
                  $("#timeSheetLoginPgUserName").focus();
                  });
    }else if($("#timeSheetLoginPgPassword").val()==""||$("#timeSheetLoginPgPassword").val()==" "||$("#timeSheetLoginPgPassword").val()==undefined || $("#timeSheetLoginPgPassword").val()== null){
        showAlert("Please enter your Password.","Timesheet", function(){
                  $("#timeSheetLoginPgPassword").focus();
                  });
    }else{
        
        /* code to find 1st and last day of the current week */
        
        timeSheetSavedFrom = "weekly";
        now = new Date();
        first = now.getDate() - now.getDay();
        first = new Date(now.setDate(first)).toUTCString();
        
        //last = new Date(now.setDate(last)).toUTCString();
        
        /* Code to find 1st day of week */
        
        firstFullDate = new Date(first);
        lastFullDate = new Date(first);
        
        day = firstFullDate.getDate()+1;
        weeklyStartDate = firstFullDate .getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = firstFullDate.getMonth()+1;
        if(month<10){
            
            month = "0"+month;
        }
        
        year = firstFullDate.getFullYear();
        firstFullDate = day+"-"+month+"-"+year;
        
        /* Code to find last day of week*/
        
        lastFullDate.setDate(lastFullDate.getDate() + 6);
        day = lastFullDate.getDate()+1;
        month = lastFullDate.getMonth() + 1;
        year = lastFullDate.getFullYear();
        
        if(day<10){
            day = "0"+day;
        }
        
        if(month<10){
            month = "0"+month;
        }
        
        lastFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employee":{
            "EmployeeNo": $("#timeSheetLoginPgUserName").val(),
            "Password": $("#timeSheetLoginPgPassword").val(),
            "frmDate":firstFullDate,
            "toDate":lastFullDate
        }
        }
        
        localStorage.setItem("currentWeekFirstDate",firstFullDate);
        localStorage.setItem("currentWeekLastDate",lastFullDate);
        
        timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                   console.log("Login"+JSON.stringify(response));
                   if (response.GetEmployeeResult.Status) {
                   localStorage.setItem("timeSheetEmployeeNumber",$("#timeSheetLoginPgUserName").val());
                   localStorage.setItem("timeSheetPassword",$("#timeSheetLoginPgPassword").val());
                   localStorage.setItem("timeSheetPayRollNumber",response.GetEmployeeResult.PayrollNumber);
                   empWorkedHours = response.GetEmployeeResult.TotalUnits;
                   timeSheetEmpName = response.GetEmployeeResult.FullName;
                   HoursPerWeek = response.GetEmployeeResult.HoursPerWeek;
                   hideLoadingIcon();
                   changePage("#timeSheetButtonPg","slide",false);
                   } else {
                   hideLoadingIcon();
                   showAlert("Invalid Username or Password.", "Timesheet");
                   }
                            });
    }
}

/*-- End Of Login Function --*/

/*-- Forgot Password Function --*/

function timsheetForgotPwd(){
    
    navigator.notification.prompt("Please enter your Employee ID", sendEmail, "Password Recovery", ["SEND PASSWORD","CANCEL"], "");

}

function sendEmail(res){
    if(res.buttonIndex == 1){
        
         parameter = {
                "employeeno":res.input1
            }
        console.log(JSON.stringify(parameter));
            timeSheetWebService("POST", "PasswordResetEmail", parameter, function(response) {
                                
                                if((response.PasswordResetEmailResult.Status)){
                                hideLoadingIcon();
                                showAlert("Please check your email to continue the password recovery process.","Email Recovery Email Sent");
                                }else{
                                hideLoadingIcon();
                                showAlert("Couldn't able to send password to your mail, please try again.","Timesheet");
                                }
                                });
        
    }else{
        console.log("no op")
    }
    
    
}

/*-- End Of Login Function --*/

/*-- Function to modify worked hours and hoursperweek --*/
function getEmpDetails(){
    
    $(".timeSheetEmpName").text(timeSheetEmpName);
    $(".timeSheetMinWrkingHrs").text(HoursPerWeek);
    $(".timeSheetEmpId").text(localStorage.getItem('timeSheetEmployeeNumber'));
    
    if(empWorkedHours==undefined || empWorkedHours==null){
        $(".timeSheetMaxWrkingHrs").text("0");
        $(".workedHoursTime").text("0");
    }else{
        $(".timeSheetMaxWrkingHrs").text(empWorkedHours);
        $(".workedHoursTime").text(empWorkedHours);
    }
    
}

/*-- End Of Login Function --*/

/*-- Timesheet Clear Filter Date Fields Function & get payperiods selectbox value i.e month details --*/

function timeSheetEmptyFromToDateField(){
    
    $("#timeSheetPgFrom").val(localStorage.getItem("searchFromDate"));
    $("#timeSheetPgTo").val(localStorage.getItem("searchToDate"));
    
    $("#timeSheetPgWeeklyPeriod").empty("");
    $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
    $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
    
    parameter = {
        "payrollNumber":localStorage.getItem("timeSheetPayRollNumber")
    }
    
    timeSheetWebService("POST", "GetPayrollPeriods", parameter, function(response) {
                        //console.log(JSON.stringify(parameter));
                        //console.log("GetPayrollPeriods"+JSON.stringify(response));
                        if ((response.GetPayrollPeriodsResult == null) || (response.GetPayrollPeriodsResult == "") || (response.GetPayrollPeriodsResult == undefined)){
                        hideLoadingIcon();
                        showAlert("Pay Periods not found please tryagin later.", "Timesheet");
                        }else{

                        for(i=0;i<response.GetPayrollPeriodsResult.length;i++){
                        
                        str = response.GetPayrollPeriodsResult[i].StartingDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        payRollPeriodStartingDate = day+"-"+month+"-"+now.getFullYear();
                        
                        str = response.GetPayrollPeriodsResult[i].EndingDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        payRollPeriodEndingDate = day+"-"+month+"-"+now.getFullYear();
                        
                        payRollPeriods[i] = {"startingDate":payRollPeriodStartingDate, "endingDate":payRollPeriodEndingDate, "IsCurrent":response.GetPayrollPeriodsResult[i].IsCurrent, "IsLocked":response.GetPayrollPeriodsResult[i].IsLocked, "Number":now.getFullYear()+""+response.GetPayrollPeriodsResult[i].Number};
                        
                        }
                        $("#timeSheetPgPayRollPeriod").empty("");
                        $("#timeSheetPgPayRollPeriod").append("<option value='0'>Payroll Periods</option>");
                        for(i=0;i<payRollPeriods.length;i++){
                        
                        $("#timeSheetPgPayRollPeriod").append("<option value="+payRollPeriods[i].Number+">"+payRollPeriods[i].startingDate+" to "+payRollPeriods[i].endingDate+"</option>");
                        $("#timeSheetPgPayRollPeriod").selectmenu().selectmenu("refresh");
                        }
                        if(localStorage.getItem("payRollPeriod") != ""){
                        $("#timeSheetPgPayRollPeriod option[value="+localStorage.getItem('payRollPeriod')+"]").prop("selected", "selected").change();
                        $("#timeSheetPgPayRollPeriod").selectmenu().selectmenu("refresh");
                        }
                        hideLoadingIcon();
                        }
                        });
    
}

/*-- End Of Clear Filter Date Fields Function --*/

/*-- Depending on the payperiod month the weekly period will be generated--*/

$("#timeSheetPgPayRollPeriod").change(function (){
        
        parameter = { "payPeriod":$("#timeSheetPgPayRollPeriod :selected").text() }
                                      
        if($("#timeSheetPgPayRollPeriod :selected").text()=="Payroll Periods"){
                                      $("#timeSheetPgWeeklyPeriod").empty("");
                                      $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
                                      $("#timeSheetPgWeeklyPeriod").selectmenu("refresh", true);
        }else{
                                      
        timeSheetWebService("POST", "GetWeeksforPayPeriod", parameter, function(response) {
                
                //console.log(JSON.stringify(parameter));
                //console.log("asfdasdf"+JSON.stringify(response));
                            
                            if ((response.GetWeeksforPayPeriodResult == null) || (response.GetWeeksforPayPeriodResult == "") || (response.GetWeeksforPayPeriodResult == undefined)){
                            hideLoadingIcon();
                            showAlert("Weekly Periods not found please try agin later.", "Timesheet");
                            }else{
                            $("#timeSheetPgWeeklyPeriod").empty("");
                            $("#timeSheetPgWeeklyPeriod").append("<option value='0'>Weekly Periods</option>");
                            for(i=0;i<response.GetWeeksforPayPeriodResult.length;i++){
                            
                            $("#timeSheetPgWeeklyPeriod").append("<option value="+response.GetWeeksforPayPeriodResult[i].Value+">"+response.GetWeeksforPayPeriodResult[i].Text+"</option>");
                            $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
                            
                            }
                            if(localStorage.getItem("weeklyPeriod") != ""){
                            $("#timeSheetPgWeeklyPeriod option[value="+localStorage.getItem('weeklyPeriod')+"]").prop("selected", "selected").change();
                            $("#timeSheetPgWeeklyPeriod").selectmenu().selectmenu("refresh");
                            }
                            }
                            hideLoadingIcon();
                            });
            }
                                      });



/*-- End Of Function --*/

/*-- Function to autofill the from and to date in search timesheet--*/

function timeSheetAutoFillFromToDateField(){

     Apploadingicon();
     weeklyPeriod = $("#timeSheetPgWeeklyPeriod :selected").text();
     weeklyPeriodSplit = weeklyPeriod.split("-");
     weeklyPeriod = weeklyPeriodSplit[2]+"-"+weeklyPeriodSplit[1]+"-"+weeklyPeriodSplit[0];
    
    
    now = new Date(weeklyPeriod);
    first = now.getDate() - now.getDay();
    first = new Date(now.setDate(first)).toUTCString();
    lastFullDate = new Date(first);
    
    lastFullDate.setDate(lastFullDate.getDate() + 7);
    day = lastFullDate.getDate();
    month = lastFullDate.getMonth() + 1;
    year = lastFullDate.getFullYear();
    
    if(day<10){
        day = "0"+day;
    }
    
    if(month<10){
        month = "0"+month;
    }
    
    lastFullDate = year+"-"+month+"-"+day;
    
    $("#timeSheetPgTo").val(lastFullDate);
    $("#timeSheetPgFrom").val(weeklyPeriod);
    hideLoadingIcon();
    
}

/*-- End Of Function --*/

/* Fuction to clear search filter fields */

function clearSearchFields(){
    
    $("#timeSheetPgFrom").val("");
    $("#timeSheetPgTo").val("");
    
}

/* End of function */

/*-- Timesheet Listview Function to fix parameter based on daily, weekly, monthly & fourtnightly--*/

function generateTimeSheetListView(type,frmPg){

    if(frmPg == "frmHomePg"){
        frm = 1;
    }else{
        frm = 0;
    }
    
    if(type=="filter"){
        
            if($("#timeSheetPgFrom").val() == ""){
            if($("#timeSheetPgFrom").is(":visible")){
                showAlert("Please enter From date.", "Timesheet");
            }else{
                console.log("no from to btn displayed to show");
            }
           
        }else if($("#timeSheetPgTo").val() == ""){
            
            if($("#timeSheetPgTo").is(":visible")){
                showAlert("Please enter To date.", "Timesheet");
            }else{
                console.log("no from to btn displayed to show");
            }
            
        }else{
            
            parameter = {
                    "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
                    "startDate":"" +$("#timeSheetPgFrom").val()+ "",
                    "endDate":"" +$("#timeSheetPgTo").val()+ ""
                }
            
            localStorage.setItem("searchFromDate",$("#timeSheetPgFrom").val());
            localStorage.setItem("searchToDate",$("#timeSheetPgTo").val());
            localStorage.setItem("payRollPeriod",$("#timeSheetPgPayRollPeriod option:selected").val());
            localStorage.setItem("weeklyPeriod",$("#timeSheetPgWeeklyPeriod option:selected").val());

            generatingTimesheetListView("filter");
            
        }
    }else if(type=="list"){
        
        timeSheetSavedFrom = "list";
        $("#timeSheetPgFrom").val("");
        $("#timeSheetPgTo").val("");
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
        parameter = { "employeeNum": localStorage.getItem("timeSheetEmployeeNumber") };
        
        generatingTimesheetListView("list");
        
    }else if(type=="daily"){
       
        /*code to find daily date*/
        /* Hide all filter for daily */
        
        $(".subHeaderLableLeftPadding").hide();
        
        timeSheetSavedFrom = "daily";
        now = new Date();
        day = now.getDate();
        month = now.getMonth()+1;
        year = now.getFullYear();
        
        if(day<10){
           day = "0"+day;
        }
        
        if(month<10){
            month = "0"+month;
        }
        
         firstFullDate = day+"-"+month+"-"+year;
         lastFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        generatingTimesheetListView("daily");
        
    }else if(type=="weekly"){
        
        /*Hide from and to filter alone*/
        
        $(".subHeaderLableLeftPadding").show();

        /*code to find 1st and last day of the current week*/
        timeSheetSavedFrom = "weekly";
       
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate": localStorage.getItem("currentWeekFirstDate"),
            "endDate": localStorage.getItem("currentWeekLastDate")
        }
        generatingTimesheetListView("weekly");
        
    /*list to show  14 days before from current days*/
        
    }else if(type=="fourtnightly"){
        
        /*Show all filter*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
         /* Code to find last day of 14 days*/
        
        timeSheetSavedFrom = "fourtnightly";
        lastFullDate = new Date();
        
        day = lastFullDate.getDate();
        if(day<10){
            day = "0"+day;
        }
        
        month = lastFullDate.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        
        year = lastFullDate.getFullYear();
        lastFullDate = day+"-"+month+"-"+year;
        
       /* Code to find first day of 14 days*/
        
        fortNightDays = new Date(+new Date - 12096e5);
        
        day = fortNightDays.getDate();
        if(day<10){
            day = "0"+day;
        }

        month = fortNightDays.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        year = fortNightDays.getFullYear();
        
        firstFullDate = day+"-"+month+"-"+year;
        
        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        
        generatingTimesheetListView("fourtnightly");
        
    }else if(type=="monthly"){
        
        /*Show all filter*/
        
        $(".subHeaderLableLeftPadding").show();
        $(".timeSheetPgFrom").show();
        $(".timeSheetPgTo").show();
        
        timeSheetSavedFrom = "monthly";
        
        /* Code to find before 30 days*/
        
        now = new Date();
        firstFullDate = new Date(now.getFullYear(),now.getMonth(),1);
        lastFullDate =  new Date(now.getFullYear(),now.getMonth()+1,0);
        
        firstFullDate = firstFullDate.getDate()+"-"+(firstFullDate.getMonth()+1)+"-"+firstFullDate.getFullYear();
        lastFullDate = lastFullDate.getDate()+"-"+(lastFullDate.getMonth()+1)+"-"+lastFullDate.getFullYear();

        parameter = {
            "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
            "startDate":"" +firstFullDate+ "",
            "endDate":"" +lastFullDate+ ""
        }
        
        generatingTimesheetListView("monthly");
    }
}


/*-- Function to generate listview based on above parameter 
 Note: also list is diffrentiated based on submitted, approved, saved and rejected method  
 0 - saved
 1 - pending  which meanse submitted orange
 2 - confirm  approved green
 3 - rejected red  --*/

function generatingTimesheetListView(type){
    
    timeSheetWebService("POST", "GetTimesheetEntries", parameter, function(response) {
//                        console.log("GetTimesheetEntries"+JSON.stringify(parameter));
                        console.log("GetTimesheetEntries"+JSON.stringify(response));
                        if (response.GetTimesheetEntriesResult.length==0 || response.GetTimesheetEntriesResult.length==null) {
                          hideLoadingIcon();
                        $("#timeSheetListview").empty();
                        showAlert("No Timesheet available.", "Timesheet");
                        }else{
                        $("#timeSheetListview").empty();
                        for(i=0;i<response.GetTimesheetEntriesResult.length;i++){
                        jobName = response.GetTimesheetEntriesResult[i].JobFullDescription;
                        taskName = response.GetTimesheetEntriesResult[i].JobTaskFullDescription;
                        units = response.GetTimesheetEntriesResult[i].Units;
                        lineNumber = response.GetTimesheetEntriesResult[i].LineNumber;
                        timeSheetStatus = response.GetTimesheetEntriesResult[i].TimesheetStatus;
                        if(response.GetTimesheetEntriesResult[i].plantEntryCount == 0){
                        noOfPlantEntry = "";
                        }else{
                        noOfPlantEntry = "<span style='line-height:50px;color:#608787;' >&nbsp;X "+response.GetTimesheetEntriesResult[i].plantEntryCount+"</span>";
                        }
                        
                        /* Date Conversion */
                        
                        str = response.GetTimesheetEntriesResult[i].WorkDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date( +str );
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        year = now.getFullYear();
                        fullDate = "" +day+"/"+month+"/"+year+ "";
                        
                        var deletelist="delete";
                        simpleList = " <li data-icon='false' style='white-space:normal;margin-bottom:5%;border:1px grey;'><div><div class='timeSheetListViewHeaderLeftPos timeSheetListViewHeaderLeftPosSavImg'>Saved</div><div style='float:right;text-shadow:none;font-size:medium;color:#165353;'>"+fullDate+"</div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");' style='color:#6C9090;'><span style='background-color:#EFEFEF;text-shadow:none;'>&nbsp;Job&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;"+jobName+"<br><br><span style='background-color:#EFEFEF;text-shadow:none;color:#6C9090;'>&nbsp;Task&nbsp;</span> &nbsp;&nbsp;"+taskName+"<br><div id='truckIcon"+lineNumber+"' style='float:left;'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");' style='background-color:#A7A5A5 !important; border:none !important;'>View</a></div></div>"+noOfPlantEntry+"</div><div style='flot:left;' class='ui-nodisc-icon'><a href='#' onclick='viewTimeSheetDetails(\""+lineNumber+"\");' class='ui-btn ui-shadow ui-corner-all ui-icon-edit ui-btn-icon-notext ui-btn-inline listEditDeleteDesign'>Edit</a><a href='#' onclick='deleteTimeSheetFn(\""+lineNumber+"\");' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline listEditDeleteDesign'>Delete</a></div><div style='float:right;margin-right:0%;'> <span style='line-height:40px;color:#558080;'> Hours:  </span>&nbsp;<div style='font-size:1.5em;float:right;height:40px;width:40px;border-radius:50%;background-color:#909090;color:#ffffff;'><p style='line-height:20px;text-align:center;'>" +units+"</p></div></div></div></li>";
                        
                        
                        submittedList = "<li data-icon='false' style='white-space:normal;margin-bottom:5%;border:1px grey;'><div><div class='timeSheetListViewHeaderLeftPos timeSheetListViewHeaderLeftPosSubImg' style='color:#7CC47F;'>Submitted</div><div style='float:right;text-shadow:none;font-size:medium;color:#165353;'>"+fullDate+"</div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");' style='color:#6C9090;'><span style='background-color:#EFEFEF;text-shadow:none;'> &nbsp;Job&nbsp;&nbsp; </span>&nbsp;&nbsp;"+jobName+"<br><br><span style='background-color:#EFEFEF;text-shadow:none;color:#6C9090;'> &nbsp;Task&nbsp;</span> &nbsp;&nbsp;"+taskName+"<br><div id='truckIcon"+lineNumber+"' style='float:left;'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");' style='background-color:#A7A5A5 !important; border:none !important;'>View</a></div></div>"+noOfPlantEntry+"</div><div style='float:right;margin-right:0%;'> <span style='line-height:40px;color:#558080;'> Hours:  </span>&nbsp;<div style='font-size:1.5em;float:right;height:40px;width:40px;border-radius:50%;background-color:#909090;color:#ffffff;'><p style='line-height:20px;text-align:center;'>" +units+"</p></div></div></div></li>";
                        
                        approvedList = " <li data-icon='false' style='white-space:normal;margin-bottom:5%;border:1px grey;'><div><div class='timeSheetListViewHeaderLeftPos timeSheetListViewHeaderLeftPosAppImg' style='color:green;'>Approved</div><div style='float:right;text-shadow:none;font-size:medium;color:#165353;'>"+fullDate+"</div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");' style='color:#6C9090;'><span style='background-color:#EFEFEF;text-shadow:none;'> &nbsp;Job&nbsp;&nbsp; </span>&nbsp;&nbsp; &nbsp;"+jobName+"<br><br><span style='background-color:#EFEFEF;'text-shadow:none;color:#6C9090;> &nbsp;Task&nbsp; </span> &nbsp;&nbsp;"+taskName+"<br><div id='truckIcon"+lineNumber+"' style='float:left;'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");' style='background-color:#A7A5A5 !important; border:none !important;'>View</a></div></div>"+noOfPlantEntry+"</div><div style='float:right;margin-right:0%;'> <span style='line-height:40px;color:#558080;'> Hours:  </span>&nbsp;<div style='font-size:1.5em;float:right;height:40px;width:40px;border-radius:50%;background-color:#909090;color:#ffffff;'><p style='line-height:20px;text-align:center;'>" +units+"</p></div></div></div></li>";
                        
                        rejectedList = "<li data-icon='false' style='white-space:normal;margin-bottom:5%;border:1px grey;'><div><div class='timeSheetListViewHeaderLeftPos timeSheetListViewHeaderLeftPosRejImg' style='color:red;'>&#10006 Rejected</div><div style='float:right;text-shadow:none;font-size:medium;color:#165353;'>"+fullDate+"</div><br><br><div onclick='viewTimeSheetDetails(\""+lineNumber+"\");' style='color:#6C9090;'><span style='background-color:#EFEFEF;text-shadow:none;'> &nbsp;Job&nbsp;&nbsp; </span>&nbsp;&nbsp; &nbsp;"+jobName+"<br><br><span style='background-color:#EFEFEF;text-shadow:none;color:#6C9090;'> &nbsp;Task&nbsp; </span> &nbsp;&nbsp;"+taskName+"<br><div id='truckIcon"+lineNumber+"' style='float:left;'><a href='#' class='ui-btn ui-nodisc-icon ui-corner-all ui-icon-truck ui-btn-icon-notext infoIcon' onclick='timeSheetViewPlantEntry(\""+lineNumber+"\");' style='background-color:#A7A5A5 !important; border:none !important;'>View</a></div></div>"+noOfPlantEntry+"</div>\<div style='flot:left;' class='ui-nodisc-icon'></div><div style='float:right;margin-right:0%;'> <span style='line-height:40px;color:#558080;'> Hours:  </span>&nbsp;<div style='font-size:1.5em;float:right;height:40px;width:40px;border-radius:50%;background-color:#909090;color:#ffffff;'><p style='line-height:20px;text-align:center;'>" +units+"</p></div></div></div></li>";

                        if(timeSheetStatus == 0){
                        $("#timeSheetListview").append(simpleList);
                        }else if(timeSheetStatus == 1){
                        $("#timeSheetListview").append(submittedList);
                        }else if(timeSheetStatus == 2){
                        $("#timeSheetListview").append(approvedList);
                        }else if(timeSheetStatus == 3){
                        $("#timeSheetListview").append(rejectedList);
                        }
                        if(response.GetTimesheetEntriesResult[i].IsPlant){
                        console.log("Dont hide");
                        }else{
                        $("#truckIcon"+lineNumber).hide();
                        }
                        }
                        if(($("#timeSheetsTheme").val())=="template1"){
                        $(".infoIcon").css({"background-color":"#74203f","border-color":"#74203f"});
                        }else if(($("#timeSheetsTheme").val())=="default"){
                        $(".infoIcon").css({"background-color":"#375BAA","border-color":"#375BAA"});
                        }
                        hideLoadingIcon();
                        changePage("#timeSheetPg","slide",false);
                        }
                        if(frm){
                        localStorage.setItem("searchFromDate","");
                        localStorage.setItem("searchToDate","");
                        localStorage.setItem("payRollPeriod","");
                        localStorage.setItem("weeklyPeriod","");
                        frm = 0;
                        }
                        $("#timeSheetListview").listview("refresh");
                        });
                        generatingTimesheetListViewType = type;
    
    
}


/*-- End Of Timesheet Listview Function --*/


/* Function when checkbox clicked popup opens */

$("#timeSheetPlantEntry").click(function(){
         
                                
/* if loop to check and apply theme for delete icon in popup, as color does not applied directly*/
                     
          popUpDeleteIcon = "<a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-inline ui-nodisc-icon plantEntryDeleteIcon' style='background-color:#EF6868'>Delete</a>";
           
        /* Loading plant no details*/
                                
        timeSheetWebService("POST", "GetPlantNumber", "", function(response) {
        //console.log("PlantNumber"+JSON.stringify(response));
                            if((response.GetPlantNumberResult.length == 0) || (response.GetPlantNumberResult.length == null) || (response.GetPlantNumberResult.length == undefined)){
                            showAlert("Couldn't able to fetch plant number, please try again later.","Timesheet");
                            }else{
                            $("#plantno").empty();
                            for(i=0;i<response.GetPlantNumberResult.length;i++){
                            $("#plantno").append("<option value="+i+">"+response.GetPlantNumberResult[i].No_+"</option>");
                            }
                            
        /* Loading work type code details*/
                            
        timeSheetWebService("POST", "GetWorkTypeCode", "", function(response) {
        //console.log("GetWorkTypeCode"+JSON.stringify(response));
                           if((response.GetWorkTypeCodeResult == null)||(response.GetWorkTypeCodeResult == undefined)||(response.GetWorkTypeCodeResult.length == 0)){
                            hideLoadingIcon();
                            showAlert("Couldn't able to fetch work type code please try again.","Timesheet");
                            }else{
                            $("#wrkTypeCode").empty();
                            for(i=0;i<response.GetWorkTypeCodeResult.length;i++){
                            $("#wrkTypeCode").append("<option value="+response.GetWorkTypeCodeResult[i].CustomerNo+">"+response.GetWorkTypeCodeResult[i].Code+"</option>");
                            }
                            $("#plantno").selectmenu("refresh", true);
                            $("#wrkTypeCode").selectmenu("refresh", true);
                            getPlantEntries();
                            }
                            });
                            }
        });
         });

/* Function to close Plant entry popup  */

function closePopUpPlantEntry(){
    $("#timeSheetPlantEntryDialog").popup("option","history",false);
    $("#timeSheetPlantEntryDialogTableContent").empty();
    $("#timeSheetPlantEntryDialog").popup("close");
}

/* End of function  */

/* Function to get plant entries */

function getPlantEntries(){
    
    //open dialog
    
    parameter = {
        "linenumber": localStorage.getItem("timeSheetListLineNumber")
    }
    
    if(localStorage.getItem("timeSheetListLineNumber") == ""){
        hideLoadingIcon();
        showAlert("Please save timesheet to add/view plant entry.","Timesheet");
        
    }else{
    timeSheetWebService("POST", "GetPlantEntries", parameter, function(response) {
                        console.log("result" + JSON.stringify(response));
                        if((response.GetPlantEntriesResult == null) || (response.GetPlantEntriesResult == undefined) || (response.GetPlantEntriesResult.length == 0)){
                        $("#timeSheetPlantEntryDialogTableContent").empty();
                        $("#timeSheetPlantEntryDialogTableContent").append("<td class='noPlantEntryContent'><td>No Plant Entries Available!</td></td>");
                        $("#timeSheetPlantEntryUnits").val("");
                        $("#timeSheetPlantEntryDialog").popup("open");
                        hideLoadingIcon();
                        }else{
                        $("#timeSheetPlantEntryDialogTableContent").empty();
                        for (i=0;i<response.GetPlantEntriesResult.length;i++){
                        $("#timeSheetPlantEntryDialogTableContent").append("<tr>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].ResourceNo+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].WorkTypeCode+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].Units+"</td>\
                                                                           <td id="+response.GetPlantEntriesResult[i].EntryNo+" onclick='timeSheetDeletePlantEntry("+response.GetPlantEntriesResult[i].EntryNo+")'>"+popUpDeleteIcon+"</td></tr>");
                        }
                        $("#timeSheetPlantEntryUnits").val("");
                        $("#timeSheetPlantEntryDialog").popup("open");
                        hideLoadingIcon();
                        }
                        });
    }
}

/*-- End Of Plant Entry Function --*/


/* Saving timesheet plant entry function  */

function timeSheetSavePlantEntry(){
   
    now = new Date();
    day = now.getDate();
    month = now.getMonth();
    month = month+1;
    year = now.getFullYear();
    
    if(day<10){
        day = "0"+day;
    }
    
    if(month<10){
        month = "0"+month;
    }

    currentDate = month+"-"+day+"-"+year;
    
    if((localStorage.getItem("timeSheetListLineNumber")== "") || (localStorage.getItem("timeSheetListLineNumber")== null) || (localStorage.getItem("timeSheetListLineNumber")== undefined)){
        
        hideLoadingIcon();
        showAlert("Please save timesheet to make a plant entry.", "Timesheet", function(){
                  $("#timeSheetPlantEntryUnits").val("");
                  $("#timeSheetPlantEntryDialog").popup("close");
                  });

    }else{
        
        if($("#timeSheetPlantEntryUnits").val() == ""){
            showAlert("Please enter Units.","Timesheet");
        }else if($("#timeSheetPlantEntryUnits").val() == 0){
            showAlert("Please enter valid Units.","Timesheet");
        }else if($("#timeSheetPlantEntryUnits").val()>24){
            showAlert("Please enter Hours less than 24 Hrs.", "Timesheet", function(){
                      $("#timeSheetPlantEntryUnits").focus();
                      });
        }else if((($("#timeSheetPlantEntryUnits").val().indexOf('.'))!= -1)&&(($("#timeSheetPlantEntryUnits").val().substring($("#timeSheetPlantEntryUnits").val().indexOf('.'), $("#timeSheetPlantEntryUnits").val().indexOf('.').length).length)>3)){
                showAlert("Please enter less than 2 decimal values.", "Timesheet", function(){
                          $("#timeSheetPlantEntryUnits").focus();
                          });
        }else{
        
    parameter =
            
        {"entry":{
            "ResourceNo": $("#plantno option:selected").text(),
            "WorkTypeCode":$("#wrkTypeCode option:selected").text(),
            "Units":$("#timeSheetPlantEntryUnits").val(),
            "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber"),
            "PayrollNo":localStorage.getItem("timeSheetPayRollNumber"),
            "WorkDate":currentDate,
            "PayJournalLineNo":localStorage.getItem("timeSheetListLineNumber")
        }
        }
    
    console.log(JSON.stringify(parameter));
    timeSheetWebService("POST", "SaveUpdatePlantEntry", parameter, function(response) {
                        console.log("SaveUpdatePlantEntry"+JSON.stringify(response));
                        if(response.SaveUpdatePlantEntryResult) {
                                  $("#timeSheetPlantEntryUnits").val("");
                                  getPlantEntries();
                        }else{
                        hideLoadingIcon();
                        showAlert("Unable to add plant entry for the timesheet.", "Timesheet");
                        }
                        });
        
    }
    }

}

/*-- End Of save Plant Entry Function --*/

/*-- Delete plant entry Function --*/

function timeSheetDeletePlantEntry(no){
    
    plantEntryNo = no;
    promptAlert("Are you sure you want to delete this Plant Entry?", deletePlantEntryConfirm, "Timesheet", "Yes", "No");
    
}

function deletePlantEntryConfirm(index){

    if(index == 1){
       parameter = {
            "entryNo":plantEntryNo
        }
        console.log("parameter"+JSON.stringify(parameter));
        timeSheetWebService("POST", "DeletePlantEntry", parameter, function(response) {
                            console.log("DeletePlantEntryResult"+JSON.stringify(response));
                            if(response.DeletePlantEntryResult){
                            $("#timeSheetPlantEntryDialogTableContent").empty();
                                      $("#timeSheetPlantEntryUnits").val("");
                                      getPlantEntries();
                            hideLoadingIcon();
                            }else{
                            hideLoadingIcon();
                            showAlert("Could'nt able to delete plant entry.", "Timesheet");
                            }
                            });
    }else{
        console.log("do nothing");
    }

}

/*-- End Of Delete Plant Entry Function --*/


/* View timesheet popup for plant entry */

function timeSheetViewPlantEntry(linenumber)
{
    plantEntriView = 1;
    parameter = {
        "linenumber": linenumber
    }
    
    timeSheetWebService("POST", "GetPlantEntries", parameter, function(response) {
                        console.log("GetPlantEntries" + JSON.stringify(response));
                        if((response.GetPlantEntriesResult == null) || (response.GetPlantEntriesResult == undefined) || (response.GetPlantEntriesResult.length == 0)){
                        showAlert("Unable to view plant entry.","Timesheet");
                        hideLoadingIcon();
                        }else{
                        $("#timeSheetViewPlantEntryPopupContent").empty();
                        for (i=0;i<response.GetPlantEntriesResult.length;i++){
                        $("#timeSheetViewPlantEntryPopupContent").append("<tr>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].ResourceNo+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].WorkTypeCode+"</td>\
                                                                           <td align='center'>"+response.GetPlantEntriesResult[i].Units+"</td></tr>");
                        }
                        $("#timeSheetViewPlantEntryPopup").popup("open");
                        hideLoadingIcon();
                        }
                        });
    
}

/*End of View timesheet popup for plant entry*/


function closeViewPopUpPlantEntry(){
    $("#timeSheetViewPlantEntryPopup").popup("close");
}

/* End of function */

/* Function to generate timesheet list when moved back from add timesheet page */

function timeSheetPreviousPage(){
    if(fromPg == "timeSheetButtonPg"){
        changePage("#timeSheetButtonPg","slide",true);
    }else if(fromPg == "timeSheetPg"){
        
        if(($("#timeSheetListview li").length)==0){
            showAlert("No Timesheet available.","Timesheet");
        }else{
        generateTimeSheetListView(generatingTimesheetListViewType);
        }
        //console.log(generatingTimesheetListViewType);
        fromViewPg = 0;
        changePage("#timeSheetPg","slide",true);
    }
}

/* End of function */

/* Function to generate timesheet select box values */

function generateTimeSheetSelectboxValues(page){

    //  selectbox Hours Type Values
    /*--inorder to make back button work from addnew this if condition is included--*/
    
    if(page == "addPg"){
        console.log("no op");
    }else{
    fromPg = $.mobile.activePage.attr("id");
    }
    
    $("#timeSheetAddSaveBtn").removeClass("ui-disabled");
    $("#timeSheetAddSaveAndSubmit").removeClass("ui-disabled");
    $("#timeSheetPlantEntry").hide();
    $("#addTimeSheetPgHoursType").val("");
    $("#addTimeSheetPgJob").val("");
    $("#addTimeSheetPgTask").val("");
    $("#addTimeSheetPgDate").val("");
    $("#addTimeSheetPgHours").val("");
    $("#addTimeSheetPgComments").val("");
    $(".addTimeSheetPgManagerComments").hide();
    $(".ui-input-clear").addClass("ui-nodisc-icon");
    
    hoursTypeListArray = [];
    jobListArray = [];
    taskListArray = [];
    taskListArrayAutoComplete = [];
    
    parameter = "";
    
    /*  Selectbox Hours Type value */
    
    timeSheetWebService("POST", "GetPayTransactionTypes", parameter, function(response) {
                        //console.log("GetPayTransactionTypes"+JSON.stringify(response));
                        hoursTypeListArray = [];
                        if (response.GetPayTransactionTypesResult.length!=0 ||response.GetPayTransactionTypesResult.length!=null) {
                        for(i=0;i<response.GetPayTransactionTypesResult.length;i++){
                        hoursTypeListArray[i] = {"value":response.GetPayTransactionTypesResult[i].Value,"data":response.GetPayTransactionTypesResult[i].Name};
                        }
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Hours Type.", "Timesheet");
                        }
                        
                        });

    
    /*  Selectbox Job value */
    
    timeSheetWebService("POST", "GetJobsList", parameter, function(response) {
                        //console.log("GetJobsList"+JSON.stringify(response));
                        jobListArray = [];
                        if (response.GetJobsListResult.length!=0 ||response.GetJobsListResult.length!=null) {
                        for(i=0;i<response.GetJobsListResult.length;i++){
                        jobListArray[i] = {"value":response.GetJobsListResult[i].Value,"data":response.GetJobsListResult[i].Name};
                        }
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Job.", "Timesheet");
                        }
                        
                        });
    
    
    /*  Selectbox Task Value */
    
    timeSheetWebService("POST", "GetJobTaskList", parameter, function(response) {
                        //console.log("GetJobTaskList"+JSON.stringify(response));
                        taskListArray = [];
                        if (response.GetJobTaskListResult.length!=0 ||response.GetJobTaskListResult.length!=null) {
                        for(i=0;i<response.GetJobTaskListResult.length;i++){
                        taskListArray[i] = {"JobNumber":response.GetJobTaskListResult[i].JobNumber,"Name":response.GetJobTaskListResult[i].Name,"Value":response.GetJobTaskListResult[i].Value};
                        }
                        changePage("#addTimeSheetPg","slide");
                        hideLoadingIcon();
                        } else {
                        hideLoadingIcon();
                        showAlert("Cannot able to fetch Task.", "Timesheet");
                        }
                        });
    
}
  
/*-- Function will be called when focus made on hourstype field and autofocus result will be generated --*/

$("#addTimeSheetPgHoursType").focus(function(){
$("#addTimeSheetPgHoursType").autocomplete({
                                           lookup: hoursTypeListArray,
                                           minChars: 0,
                                           showNoSuggestionNotice: true,
                                           noSuggestionNotice: "No Match Found"
                                           });
                                    });



/*-- Function will be called when focus made on joblist field and autofocus result will be generated --*/

$("#addTimeSheetPgJob").focus(function(){
$("#addTimeSheetPgJob").autocomplete({
                                     lookup: jobListArray,
                                     minChars: 0,
                                     showNoSuggestionNotice: true,
                                     noSuggestionNotice: "No Match Found",
                                     onInvalidateSelection:onJobChange(),
                                     onSelect: function (suggestion) {
                                     addTimeSheetPgJobChange(suggestion.data);
                                     }
                                     });
                                     });

/*-- Function will be everytime when change made on job field to enter "NO TASK SELECTED" text in task field  --*/

function onJobChange(){
   
    $("#addTimeSheetPgTask").val("NO TASK SELECTED");
}

/*-- Function to fill task data in array where this tasks is based on job selected in job field--*/

function addTimeSheetPgJobChange(jobno) {
    
                                Apploadingicon();
                                taskListArrayAutoComplete = [];
                                j=0;
                               for(i=0;i<taskListArray.length;i++){
                               if(jobno == taskListArray[i].JobNumber){
    taskListArrayAutoComplete[j] = {"value":taskListArray[i].Name+" - "+taskListArray[i].Value,"data":taskListArray[i].Name};
                                   j++;
                               }
                               }
                               hideLoadingIcon();
    
                      }

/*-- Function will be called when focus made on tasklist field and autofocus result will be generated --*/

$("#addTimeSheetPgTask").focus(function(){
$("#addTimeSheetPgTask").autocomplete({
                                      lookup: taskListArrayAutoComplete,
                                      minChars: 0,
                                      showNoSuggestionNotice: true,
                                      noSuggestionNotice: "No Match Found",
                                      onInvalidateSelection:onTaskChange(),
                                      });
                                  });

/*-- Function will be called whenever changes made on task field --*/

function onTaskChange(){
    $("addTimeSheetPgJob").val("NO JOB SELECTED");
}

/* End of function */

/*-- View Timesheet Function --*/

function viewTimeSheetDetails(lineno){
    if(plantEntriView){
        plantEntriView = 0;
    }else{
    fromViewPg = 1;
    localStorage.setItem("timeSheetListLineNumber",lineno);
    generateTimeSheetSelectboxValues();
    $(".changePasswordStyle").text("Edit Timesheet Entry");
    parameter = {
    "lineNumber":lineno
    }

    timeSheetWebService("POST", "GetTimesheetEntry", parameter, function(response) {
                        //console.log("GetTimesheetEntry"+JSON.stringify(response));
                        if (response.GetTimesheetEntryResult.Status) {
                        /*timesheet status 2 which means that particular timesheet have been submitted already*/
                        if(response.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2 || response.GetTimesheetEntryResult.TimesheetStatus == 3){
                        $("#timeSheetAddSaveBtn").addClass("ui-disabled");
                        $("#timeSheetAddSaveAndSubmit").addClass("ui-disabled");
                        $("#timeSheetPlantEntry").hide();
                        }else{
                        $("#timeSheetAddSaveBtn").removeClass("ui-disabled");
                        $("#timeSheetAddSaveAndSubmit").removeClass("ui-disabled");
                        $("#timeSheetPlantEntry").show();
                        }

                        if(response.GetTimesheetEntryResult.TimesheetStatus == 3){
                        $(".addTimeSheetPgManagerComments").show();
                        }else{
                        $(".addTimeSheetPgManagerComments").hide();
                        }
                        
                        str = response.GetTimesheetEntryResult.WorkDate;
                        str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                        now = new Date(+str);
                        day = ("0" + now.getDate()).slice(-2);
                        month = ("0" + (now.getMonth() + 1)).slice(-2);
                        fullDate = now.getFullYear()+"-"+month+"-"+day;
                        
                        $("#addTimeSheetPgDate").val(fullDate);
                        $("#addTimeSheetPgHoursType").val(response.GetTimesheetEntryResult.TransactionType);
                        $("#addTimeSheetPgJob").val(response.GetTimesheetEntryResult.JobFullDescription);
                        $("#addTimeSheetPgHours").val(response.GetTimesheetEntryResult.Units);
                        $("#addTimeSheetPgComments").val(response.GetTimesheetEntryResult.EmployeeComments);
                        $("#addTimeSheetPgManagerComments").val(response.GetTimesheetEntryResult.ManagerComments);
                        
                        for(i=0;i<jobListArray.length;i++){
                        if((jobListArray[i].value) == ($("#addTimeSheetPgJob").val())){
                        jobno = jobListArray[i].data;
                        }
                        }
                            taskListArrayAutoComplete = [];
                            j=0;
                            for(i=0;i<taskListArray.length;i++){
                                if(jobno == taskListArray[i].JobNumber){
                                    taskListArrayAutoComplete[j] = {"value":taskListArray[i].Name+" - "+taskListArray[i].Value,"data":taskListArray[i].Name};
                                    j++;
                                }
                            }

                        $("#addTimeSheetPgTask").val(response.GetTimesheetEntryResult.JobTaskFullDescription);
                        hideLoadingIcon();
                        changePage("#addTimeSheetPg","slide");
                        } else {
                        hideLoadingIcon();
                        showAlert("Unable to view timesheet details please try again.", "Timesheet");
                        }
                        });
    }
}

/*-- End Of View Timesheet Function --*/

/*-- Save, Save&New, Submit Timesheet Listview Function --*/

function timeSheetSaveNew(type){
    
    now = new Date($("#addTimeSheetPgDate").val());
    day = now.getDate();
    if (day<10){
        day = "0"+day;
    }
    month = now.getMonth()+1;
    if(month<10){
        month = "0"+month;
    }
    year = now.getFullYear();
    fullDate = day+"-"+month+"-"+year;
    
    if($("#addTimeSheetPgDate").val() == "") {
        showAlert("Please enter Date.", "Timesheet", function(){
                  $("#addTimeSheetPgDate").focus();
                  });
    }else if($("#addTimeSheetPgHoursType").val()==""){
        showAlert("Please enter Hours Type.", "Timesheet", function(){
                  $("#addTimeSheetPgHoursType").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()==""){
        showAlert("Please enter Hours.", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()==0){
        showAlert("Please enter valid Hours.", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else if($("#addTimeSheetPgHours").val()>24){
        showAlert("Please enter Hours less than 24 Hrs.", "Timesheet", function(){
                  $("#addTimeSheetPgHours").focus();
                  });
    }else if((($("#addTimeSheetPgHours").val().indexOf('.'))!= -1)&&(($("#addTimeSheetPgHours").val().substring($("#addTimeSheetPgHours").val().indexOf('.'), $("#addTimeSheetPgHours").val().indexOf('.').length).length)>3)){
             showAlert("Please enter less than 2 decimal values.", "Timesheet", function(){
                       $("#addTimeSheetPgHours").focus();
                       });
 
    }else{
    
        for(i=0;i<hoursTypeListArray.length;i++){
            if(hoursTypeListArray[i].value == $("#addTimeSheetPgHoursType").val()){
               hoursTypeTextFieldValue  = hoursTypeListArray[i].data;
            }
        }
        
        for(i=0;i<jobListArray.length;i++){
            if(jobListArray[i].value == $("#addTimeSheetPgJob").val()){
                jobListTextFieldValue = jobListArray[i].data;
            }
        }
        
        if((jobListTextFieldValue == null) || (jobListTextFieldValue == "") || (jobListTextFieldValue == undefined)){
           
                jobListTextFieldValue = "NO JOB SELECTED";
        }
        
        if((hoursTypeTextFieldValue == null) || (hoursTypeTextFieldValue == "") || (hoursTypeTextFieldValue == undefined)){
            
            hoursTypeTextFieldValue = "";
        }
        
        if(jobListTextFieldValue == "NO JOB SELECTED"){
            
            taskListTextFieldValue = "NO TASK SELECTED";
            
        }else{
            
        for(i=0;i<taskListArrayAutoComplete.length;i++){
            
            if(($("#addTimeSheetPgTask").val() == "") || ($("#addTimeSheetPgTask").val() == "NO TASK SELECTED")){
                
                taskListTextFieldValue = "NO TASK SELECTED";
                
            }else if(taskListArrayAutoComplete[i].value == $("#addTimeSheetPgTask").val()){
                
                    taskListTextFieldValue = taskListArrayAutoComplete[i].data;
            }
        }
        }
        
    if((type=="saveandnew") || (type=="save")){
        
        console.log("fromViewPg"+fromViewPg);
        if(fromViewPg==1){
            
            if(localStorage.getItem("timeSheetListLineNumber")==""){
                localStorage.setItem("timeSheetListLineNumber","-1")
            }
            
            parameter =
            {"entry":
                {
                    "lineNo":localStorage.getItem("timeSheetListLineNumber"),
                    "JobId": jobListTextFieldValue,
                    "TaskId": taskListTextFieldValue,
                    "EntryDate":fullDate,
                    "Hours":$("#addTimeSheetPgHours").val(),
                    "TransactionType":hoursTypeTextFieldValue,
                    "Comments":$("#addTimeSheetPgComments").val(),
                    "Status":"0",
                    "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber")
                }
            }
        }else{
            
        parameter =
            
        {"entry":
            {
                "lineNo":"-1",
                "JobId":jobListTextFieldValue,
                "TaskId":taskListTextFieldValue,
                "EntryDate":fullDate,
                "Hours":$("#addTimeSheetPgHours").val(),
                "TransactionType":hoursTypeTextFieldValue,
                "Comments":$("#addTimeSheetPgComments").val(),
                "Status":"0",
                "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber")
            }
        }
          fromViewPg = 1;
        }
        
        console.log("Parameter"+JSON.stringify(parameter));
        if(hoursTypeTextFieldValue == null || hoursTypeTextFieldValue == "" || hoursTypeTextFieldValue == undefined){
            $("#addTimeSheetPgHoursType").val("");
            $("#addTimeSheetPgHoursType").focus();
            hideLoadingIcon();
            showAlert("Please enter correct hours type.","Timesheet");
        }else{
            
        timeSheetWebService("POST", "SaveUpdateTimesheetEntry", parameter, function(response) {
                            //console.log("SaveTimesheetEntry"+JSON.stringify(parameter));
                            if(response.SaveUpdateTimesheetEntryResult.Status) {
                            hideLoadingIcon();
                            showAlert("Timesheet added/updated successfully.", "Timesheet", function(){
                                      hoursTypeTextFieldValue = "";
                                      jobListTextFieldValue = "";
                                      taskListTextFieldValue = "";
                                      $("#timeSheetPlantEntry").show();
                                      if(type=="saveandnew"){
                                      generateTimeSheetSelectboxValues('addPg');
                                      $("#addTimeSheetPgDate").val();
                                      $("#addTimeSheetPgHours").val();
                                      $("#addTimeSheetPgComments").val();
                                      $("#addTimeSheetPgHoursType").val("");
                                      $("#addTimeSheetPgJob").val("");
                                      $("#addTimeSheetPgTask").val("");
                                      localStorage.setItem("timeSheetListLineNumber","");
                                      }else{
                                      localStorage.setItem("timeSheetListLineNumber",response.SaveUpdateTimesheetEntryResult.Number);
                                      $("#timeSheetSubmittedIcon").removeClass("ui-disabled");
                                      $("#timeSheetDeleteIcon").removeClass("ui-disabled");
                                      }
                                      });
                            } else {
                            hideLoadingIcon();
                            showAlert("Unable to add timesheet please try again.", "Timesheet");
                            }
                            });
        }
        
    }else if(type=="submit"){
       
        now = new Date();
        day = now.getDate();
        if (day<10){
            day = "0"+day;
        }
        month = now.getMonth()+1;
        if(month<10){
            month = "0"+month;
        }
        year = now.getFullYear();
        submitFullDate = day+"-"+month+"-"+year;
        
        multiplePromptAlert("Timesheet submission period based on?", timeSheetSubmission, "Timesheet", "Current", "Weekly", "Cancel");
        
    }
}
}

/*-- End Of Save, Save&New Timesheet Listview Function --*/

/* Function to submit timesheet*/

function timeSheetSubmission(index){
 
    /*-- Individual timesheet submission --*/
    if(index==1){
        
        parameter =
        {   "employeeNumber":localStorage.getItem("timeSheetEmployeeNumber"),
            "submittedDate":submitFullDate,
            "startDate":fullDate,
            "endDate":fullDate,
            "lineNumber":localStorage.getItem("timeSheetListLineNumber")
        }
        
        timeSheetWebService("POST", "SubmitEmployeeTimesheetByWeek", parameter, function(response) {
                            console.log("SubmitEmployeeTimesheetByWeek"+JSON.stringify(response));
                            if(response.SubmitEmployeeTimesheetByWeekResult){
                            parameter = {
                            "employee":{
                            "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber"),
                            "Password":localStorage.getItem("timeSheetPassword"),
                            "frmDate":localStorage.getItem("currentWeekFirstDate"),
                            "toDate":localStorage.getItem("currentWeekLastDate")
                            }
                            }
                            timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                                                //console.log("GetEmployee"+JSON.stringify(response));
                                                if (response.GetEmployeeResult.Status) {
                                                empWorkedHours = response.GetEmployeeResult.TotalUnits;
                                                /*-- To generate list after submission base on daily,weekly,fourtnightly & monthly or all --*/
                                                showAlert("Timesheet submitted successfully.", "Timesheet", function(){
                                                          getEmpDetails();
                                                          if(fromPg == "timeSheetButtonPg"){
                                                          changePage("#timeSheetButtonPg","slide",true);
                                                          hideLoadingIcon();
                                                          }else{
                                                          if(timeSheetSavedFrom=="daily"){
                                                          generateTimeSheetListView('daily');
                                                          }else if(timeSheetSavedFrom=="weekly"){
                                                          generateTimeSheetListView('weekly');
                                                          }else if(timeSheetSavedFrom=="fourtnightly"){
                                                          generateTimeSheetListView('fourtnightly');
                                                          }else if(timeSheetSavedFrom=="monthly"){
                                                          generateTimeSheetListView('monthly');
                                                          }else{
                                                          generateTimeSheetListView('list');
                                                          }
                                                          }
                                                          fromViewPg = 0;
                                                          });

                                                }
                                                });
                            }else{
                            showAlert("Unable to submit timesheet please try again.", "Timesheet");
                            hideLoadingIcon();
                            }
                            });
      /*-- Weekly timesheet submission --*/
    }else if(index==2){
       
        parameter =
        {   "employeeNumber":localStorage.getItem("timeSheetEmployeeNumber"),
            "submittedDate":submitFullDate,
            "startDate":localStorage.getItem("currentWeekFirstDate"),
            "endDate":localStorage.getItem("currentWeekLastDate"),
            "lineNumber":"0"
        }

        timeSheetWebService("POST", "SubmitEmployeeTimesheetByWeek", parameter, function(response) {
                            //console.log("SubmitEmployeeTimesheetByWeek"+JSON.stringify(response));
                            if(response.SubmitEmployeeTimesheetByWeekResult){
                            parameter = {
                            "employee":{
                            "EmployeeNo":localStorage.getItem("timeSheetEmployeeNumber"),
                            "Password":localStorage.getItem("timeSheetPassword"),
                            "frmDate":localStorage.getItem("currentWeekFirstDate"),
                            "toDate":localStorage.getItem("currentWeekLastDate")
                            }
                            }
                            
                            timeSheetWebService("POST", "GetEmployee", parameter, function(response) {
                                                if (response.GetEmployeeResult.Status) {
                                                empWorkedHours = response.GetEmployeeResult.TotalUnits;
                                                }
                                                });
                            
                            hideLoadingIcon();
                            showAlert("Timesheet submitted successfully.", "Timesheet", function(){
                                      getEmpDetails();
                                      if(timeSheetSavedFrom=="daily"){
                                      generateTimeSheetListView('daily');
                                      }else if(timeSheetSavedFrom=="weekly"){
                                      generateTimeSheetListView('weekly');
                                      }else if(timeSheetSavedFrom=="fourtnightly"){
                                      generateTimeSheetListView('fourtnightly');
                                      }else if(timeSheetSavedFrom=="monthly"){
                                      generateTimeSheetListView('monthly');
                                      }else{
                                      generateTimeSheetListView('list');
                                      }
                                      });
                            }else{
                            showAlert("Unable to submit timesheet please try again.", "Timesheet");
                            hideLoadingIcon();
                            }
                            });

    }else{
        console.log("cancel");
    }
    
}

/*--End of function --*/

function deleteTimeSheetFn(lineno){
    
    parameter = {
        "lineNum":lineno
    }
    
    promptAlert("Are you sure you want to delete this Timesheet?", deleteTimeSheet, "Timesheet", "Yes", "No");
}

/*--Function to delete timesheet (only if it is saved or rejected it can be deleted) --*/

function deleteTimeSheet(ind){
    if(ind==1){
    timeSheetWebService("POST", "DeleteTimesheetEntry", parameter, function(response) {
                        //console.log(JSON.stringify(response));
                        if(response.DeleteTimesheetEntryResult){
                        hideLoadingIcon();
                        showAlert("Timesheet Deleted Successfully.", "Timesheet", function(){
                                  if(timeSheetSavedFrom=="daily"){
                                  generateTimeSheetListView('daily');
                                  }else if(timeSheetSavedFrom=="weekly"){
                                  generateTimeSheetListView('weekly');
                                  }else if(timeSheetSavedFrom=="fourtnightly"){
                                  generateTimeSheetListView('fourtnightly');
                                  }else if(timeSheetSavedFrom=="monthly"){
                                  generateTimeSheetListView('monthly');
                                  }else{
                                  generateTimeSheetListView('list');
                                  }
                                  fromViewPg = 0;
                                  });
                        
                        }else{
                        hideLoadingIcon();
                        showAlert("Unable To Delete Timesheet.", "Timesheet");
                        }
                        });
    }else{
        console.log("same pg");
    }

}

/*--End of function --*/

/*--Function to cancel timesheet from view timesheet page--*/

function timeSheetCancel(){
    
    promptAlert("Are you sure you want to cancel the changes?", cancelTimeSheet, "Timesheet", "Yes", "No");
    
}


function cancelTimeSheet(index){
    if(index=="1"){
        if(fromPg == "timeSheetButtonPg"){
            console.log("no need to generatetimesheet");
            changePage("#timeSheetButtonPg", "slide", true);
        }else{
            generateTimeSheetListView(generatingTimesheetListViewType);
            fromViewPg = 0;
            changePage("#timeSheetPg", "slide", true);
        }
        
    }else if(index=="2"){
        console("no op");
    }
}

//To open filter toggle

$( "#clickme" ).click(function() {
                      $("#timeSheetPgPayRollPeriod-button,#timeSheetPgWeeklyPeriod-button").addClass("ui-nodisc-icon").find(".ui-nodisc-icon").css("padding-right","20px");
                      $( "#subHeaderLableLeftPadding" ).slideToggle( "slow", function() {
                            if($('#subHeaderLableLeftPadding').is(':hidden')){
                              $("#clickme").removeClass("ui-icon-carat-u");
                              $("#clickme").addClass("ui-icon-carat-d");
                       }else{
                              $("#clickme").removeClass("ui-icon-carat-d");
                              $("#clickme").addClass("ui-icon-carat-u");
                       }
                       });
                      });

/*--End of function --*/
